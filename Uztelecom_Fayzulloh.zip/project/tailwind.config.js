/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#E6F7FC',
          100: '#CCEFF9',
          200: '#99DFF3',
          300: '#66CFEC',
          400: '#33BBE6',
          500: '#00A3E0',
          600: '#0086B8',
          700: '#006A93',
          800: '#00506F',
          900: '#003852',
        },
        navy: {
          50: '#F0F5F9',
          100: '#D9E4EE',
          200: '#B3C9DD',
          300: '#7DA6C4',
          400: '#4C7FA6',
          500: '#2C6188',
          600: '#1D4B6E',
          700: '#123856',
          800: '#0A2740',
          900: '#002B49',
          950: '#001A2D',
        },
        success: {
          50: '#ECFDF3',
          100: '#D1FADF',
          500: '#12B76A',
          600: '#039855',
          700: '#027A48',
        },
        warning: {
          50: '#FFFAEB',
          100: '#FEF0C7',
          500: '#F79009',
          600: '#DC6803',
          700: '#B54708',
        },
        error: {
          50: '#FEF3F2',
          100: '#FEE4E2',
          500: '#F04438',
          600: '#D92D20',
          700: '#B42318',
        },
      },
      boxShadow: {
        card: '0 1px 2px rgba(0, 43, 73, 0.06), 0 8px 24px -8px rgba(0, 43, 73, 0.12)',
        glow: '0 0 0 4px rgba(0, 163, 224, 0.18)',
      },
    },
  },
  plugins: [],
};
