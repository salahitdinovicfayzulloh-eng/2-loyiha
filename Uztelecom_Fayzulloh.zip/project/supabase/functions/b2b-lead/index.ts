import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SERVICE_LABELS: Record<string, string> = {
  cloud: "Ma'lumotlar markazi: bulut hosting",
  fiber: "Ajratilgan optik tolali liniyalar",
  pbx: "Virtual telefon markazi (PBX)",
  security: "Kiberxavfsizlik",
};

const PHONE_PATTERN = /^\+?[0-9\s()-]{7,20}$/;

interface Lead {
  fullName: string;
  company: string;
  phone: string;
  service: string;
}

function parseLead(body: unknown): Lead | null {
  if (!body || typeof body !== "object") return null;
  const { fullName, company, phone, service } = body as Record<string, unknown>;
  if (typeof fullName !== "string" || typeof company !== "string" || typeof phone !== "string" || typeof service !== "string") {
    return null;
  }
  const lead = { fullName: fullName.trim(), company: company.trim(), phone: phone.trim(), service };
  if (!lead.fullName || lead.fullName.length > 120) return null;
  if (!lead.company || lead.company.length > 160) return null;
  if (!PHONE_PATTERN.test(lead.phone)) return null;
  if (!(service in SERVICE_LABELS)) return null;
  return lead;
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function notifyTelegram(lead: Lead) {
  const token = Deno.env.get("TELEGRAM_BOT_TOKEN");
  const chatId = Deno.env.get("TELEGRAM_CHAT_ID");
  if (!token || !chatId) throw new Error("Telegram sozlamalari topilmadi");

  const time = new Date().toLocaleString("uz-UZ", { timeZone: "Asia/Tashkent" });
  const text = [
    "Yangi B2B so'rov",
    "",
    `Ism familiya: ${lead.fullName}`,
    `Kompaniya: ${lead.company}`,
    `Telefon: ${lead.phone}`,
    `Xizmat: ${SERVICE_LABELS[lead.service]}`,
    `Vaqt: ${time}`,
  ].join("\n");

  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text }),
  });
  if (!response.ok) throw new Error(`Telegram xatosi: ${response.status}`);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const lead = parseLead(await req.json().catch(() => null));
    if (!lead) return json({ ok: false, error: "Noto'g'ri ma'lumot" }, 400);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { error } = await supabase.from("b2b_leads").insert({
      full_name: lead.fullName,
      company: lead.company,
      phone: lead.phone,
      service: lead.service,
    });
    if (error) throw error;

    await notifyTelegram(lead);
    return json({ ok: true });
  } catch (err) {
    console.error("b2b-lead xatosi:", err);
    return json({ ok: false, error: "So'rovni qayta ishlab bo'lmadi" }, 500);
  }
});
