import { useState } from 'react';
import { ChevronDown, Router } from 'lucide-react';
import { ROUTER_GUIDES } from '@/data/routerGuides';

export default function RouterGuides() {
  const [activeId, setActiveId] = useState<string>(ROUTER_GUIDES[0].id);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        {ROUTER_GUIDES.map((guide) => {
          const isActive = guide.id === activeId;
          return (
            <button
              key={guide.id}
              type="button"
              aria-expanded={isActive}
              onClick={() => setActiveId(guide.id)}
              className={`card group flex items-center gap-4 p-5 text-left transition duration-300 hover:-translate-y-1 hover:shadow-lg focus:outline-none focus-visible:ring-4 focus-visible:ring-brand-500/30 ${
                isActive ? 'border-brand-500 ring-2 ring-brand-500/30 dark:border-brand-400' : ''
              }`}
            >
              <span
                className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl transition duration-300 ${
                  isActive
                    ? 'bg-brand-500 text-white'
                    : 'bg-brand-50 text-brand-600 group-hover:bg-brand-500 group-hover:text-white dark:bg-navy-800 dark:text-brand-300'
                }`}
              >
                <Router className="h-6 w-6" />
              </span>
              <span className="flex-1">
                <span className="block text-base font-bold text-navy-900 dark:text-white">{guide.brand}</span>
                <span className="block text-sm text-navy-500 dark:text-navy-300">{guide.model}</span>
              </span>
              <ChevronDown
                className={`h-5 w-5 text-navy-400 transition duration-300 ${isActive ? 'rotate-180 text-brand-500' : ''}`}
              />
            </button>
          );
        })}
      </div>

      {ROUTER_GUIDES.map((guide) => {
        if (guide.id !== activeId) return null;
        return (
          <ol key={guide.id} className="card grid gap-4 p-6 sm:p-8 md:grid-cols-2 lg:grid-cols-3">
            {guide.steps.map((step, index) => (
              <li
                key={step.title}
                className="flex gap-4 rounded-xl p-4 transition hover:bg-brand-50/60 dark:hover:bg-navy-800/60"
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-navy-900 text-sm font-bold text-white dark:bg-brand-500">
                  {index + 1}
                </span>
                <span>
                  <span className="block font-semibold text-navy-900 dark:text-white">{step.title}</span>
                  <span className="mt-1 block text-sm leading-relaxed text-navy-600 dark:text-navy-300">
                    {step.description}
                  </span>
                </span>
              </li>
            ))}
          </ol>
        );
      })}
    </div>
  );
}
