import { CheckCircle2, Activity } from 'lucide-react';

const REGIONAL_STATUS = [
  { name: 'Toshkent shahri', value: 99.9 },
  { name: 'Toshkent viloyati', value: 99.8 },
  { name: 'Samarqand', value: 99.7 },
  { name: "Farg'ona vodiysi", value: 99.8 },
  { name: 'Buxoro', value: 99.6 },
];

export default function NetworkStatus() {
  return (
    <div className="card relative overflow-hidden p-6 sm:p-8">
      <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-success-500/10 blur-2xl" />
      <div className="relative grid gap-8 lg:grid-cols-5 lg:items-center">
        <div className="lg:col-span-2">
          <span className="inline-flex items-center gap-2 rounded-full bg-success-50 px-3 py-1 text-xs font-semibold text-success-700 dark:bg-success-700/20 dark:text-success-100">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success-500 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-success-500" />
            </span>
            Tarmoq holati: Barqaror
          </span>
          <p className="mt-5 text-lg font-semibold text-navy-900 dark:text-white">
            Toshkent va viloyatlar bo'yicha tarmoq holati: 99.8% Barqaror
          </p>
          <div className="mt-5 h-3 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-800">
            <div className="h-full w-[99.8%] rounded-full bg-gradient-to-r from-brand-400 to-success-500 transition-all duration-1000" />
          </div>
          <p className="mt-3 flex items-center gap-2 text-sm text-navy-600 dark:text-navy-300">
            <Activity className="h-4 w-4 text-brand-500" />
            Hozirda barcha asosiy tugunlar ishlamoqda
          </p>
        </div>

        <ul className="grid gap-3 sm:grid-cols-2 lg:col-span-3">
          {REGIONAL_STATUS.map((region) => (
            <li
              key={region.name}
              className="flex items-center justify-between rounded-xl border border-navy-100 bg-navy-50/60 px-4 py-3 transition hover:border-brand-300 hover:bg-white dark:border-navy-700 dark:bg-navy-800/60 dark:hover:bg-navy-800"
            >
              <span className="flex items-center gap-2 text-sm font-medium text-navy-800 dark:text-navy-100">
                <CheckCircle2 className="h-4 w-4 text-success-600" />
                {region.name}
              </span>
              <span className="text-sm font-bold text-navy-900 tabular-nums dark:text-white">{region.value}%</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
