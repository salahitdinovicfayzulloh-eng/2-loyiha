import { useEffect, useRef, useState, type FormEvent } from 'react';
import { MessageCircle, Send, X, Bot } from 'lucide-react';

interface ChatMessage {
  id: number;
  from: 'bot' | 'user';
  text: string;
}

const GREETING: ChatMessage = {
  id: 0,
  from: 'bot',
  text: "Assalomu alaykum! Uztelecom yordamchisiman. Tarif, ulanish yoki router sozlamalari bo'yicha savolingizni yozing.",
};

const AUTO_REPLY = "Rahmat! Bu demo oynasi. Haqiqiy loyihada mutaxassisimiz tez orada javob beradi.";

export default function LiveChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([GREETING]);
  const [draft, setDraft] = useState('');
  const nextIdRef = useRef(1);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text) return;

    const userMessage: ChatMessage = { id: nextIdRef.current++, from: 'user', text };
    setMessages((current) => [...current, userMessage]);
    setDraft('');

    window.setTimeout(() => {
      setMessages((current) => [...current, { id: nextIdRef.current++, from: 'bot', text: AUTO_REPLY }]);
    }, 900);
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3 sm:bottom-6 sm:right-6">
      <div
        className={`w-[calc(100vw-2.5rem)] origin-bottom-right overflow-hidden rounded-2xl border border-navy-100 bg-white shadow-2xl transition duration-300 sm:w-96 dark:border-navy-700 dark:bg-navy-900 ${
          open ? 'visible scale-100 opacity-100' : 'invisible scale-95 opacity-0'
        }`}
        aria-hidden={!open}
      >
        <div className="flex items-center justify-between bg-navy-900 px-5 py-4 text-white">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-500">
              <Bot className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold">Onlayn yordamchi</p>
              <p className="flex items-center gap-1.5 text-xs text-navy-200">
                <span className="h-1.5 w-1.5 rounded-full bg-success-500" />
                Demo rejimi
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Chatni yopish"
            className="rounded-lg p-1.5 text-navy-200 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div ref={listRef} className="h-72 space-y-3 overflow-y-auto bg-navy-50/60 p-4 dark:bg-navy-950/60">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.from === 'user' ? 'justify-end' : 'justify-start'}`}>
              <p
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm ${
                  message.from === 'user'
                    ? 'rounded-br-md bg-brand-500 text-white'
                    : 'rounded-bl-md bg-white text-navy-800 dark:bg-navy-800 dark:text-navy-100'
                }`}
              >
                {message.text}
              </p>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex items-center gap-2 border-t border-navy-100 p-3 dark:border-navy-800">
          <input
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            placeholder="Xabar yozing..."
            aria-label="Xabar"
            className="field !rounded-full !py-2.5"
          />
          <button
            type="submit"
            aria-label="Yuborish"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-500 text-white transition hover:bg-brand-600 focus:outline-none focus-visible:ring-4 focus-visible:ring-brand-500/40"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>

      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        className="group flex items-center gap-2 rounded-full bg-brand-500 py-3.5 pl-4 pr-5 font-semibold text-white shadow-lg transition duration-300 hover:-translate-y-1 hover:bg-brand-600 hover:shadow-xl focus:outline-none focus-visible:ring-4 focus-visible:ring-brand-500/40"
      >
        {open ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5 transition group-hover:scale-110" />}
        <span className="text-sm">{open ? 'Yopish' : 'Jonli chat'}</span>
      </button>
    </div>
  );
}
