import type { ReactNode } from 'react';

interface SectionProps {
  id: string;
  eyebrow: string;
  title: string;
  description?: string;
  children: ReactNode;
  className?: string;
}

export default function Section({ id, eyebrow, title, description, children, className = '' }: SectionProps) {
  return (
    <section id={id} className={`scroll-mt-20 px-4 py-20 sm:px-6 sm:py-24 lg:px-8 ${className}`}>
      <div className="mx-auto max-w-7xl">
        <header className="mx-auto mb-12 max-w-3xl text-center">
          <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-brand-600 dark:text-brand-300">
            {eyebrow}
          </p>
          <h2 className="section-title">{title}</h2>
          {description && (
            <p className="mt-4 text-base leading-relaxed text-navy-600 sm:text-lg dark:text-navy-300">{description}</p>
          )}
        </header>
        {children}
      </div>
    </section>
  );
}
