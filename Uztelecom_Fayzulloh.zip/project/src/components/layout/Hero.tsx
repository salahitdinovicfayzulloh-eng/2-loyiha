import { ArrowRight, Gauge, ShieldCheck } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative isolate overflow-hidden bg-navy-900 pt-32 pb-20 sm:pt-40 sm:pb-28">
      <img
        src="https://images.pexels.com/photos/4486718/pexels-photo-4486718.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
        alt=""
        aria-hidden="true"
        className="absolute inset-0 -z-10 h-full w-full object-cover opacity-30"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-navy-950/95 via-navy-900/85 to-brand-900/70" />
      <div className="absolute -top-32 right-0 -z-10 h-96 w-96 rounded-full bg-brand-500/20 blur-3xl" />

      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div className="text-center lg:text-left">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-400/40 bg-brand-500/10 px-4 py-1.5 text-xs font-semibold text-brand-200">
            <span className="h-2 w-2 animate-pulse rounded-full bg-success-500" />
            Tarmoq faol ishlamoqda
          </span>
          <h1 className="mt-6 text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
            O'zbekiston bo'ylab tezkor va barqaror telekommunikatsiya xizmatlari
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-navy-100 sm:text-lg lg:mx-0">
            Tariflarni hisoblang, tarmoq qamrovini tekshiring va texnik yordam oling — barchasi bitta interaktiv
            platformada.
          </p>
          <div className="mt-10 flex flex-col items-stretch justify-center gap-3 sm:flex-row lg:justify-start">
            <a href="#tarif" className="btn-primary group">
              Tarif tanlash
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </a>
            <a
              href="#qamrov"
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/30 bg-white/5 px-6 py-3 font-semibold text-white backdrop-blur transition duration-200 hover:-translate-y-0.5 hover:bg-white/15 focus:outline-none focus-visible:ring-4 focus-visible:ring-white/30"
            >
              <Gauge className="h-4 w-4" />
              Tezlik testi o'tkazish
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {[
            { value: '99.8%', label: 'Tarmoq barqarorligi' },
            { value: '5G', label: 'Keng qamrovli yangi avlod' },
            { value: '24/7', label: 'Texnik yordam xizmati' },
            { value: 'Optik', label: 'Tolali optik internet' },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-2xl border border-white/10 bg-white/5 p-6 text-center backdrop-blur transition duration-300 hover:-translate-y-1 hover:border-brand-400/50 hover:bg-white/10"
            >
              <p className="text-3xl font-bold text-white">{stat.value}</p>
              <p className="mt-2 text-sm text-navy-200">{stat.label}</p>
            </div>
          ))}
          <div className="col-span-2 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-5 text-sm text-navy-100 backdrop-blur">
            <ShieldCheck className="h-5 w-5 shrink-0 text-brand-300" />
            Ma'lumotlaringiz himoyalangan va barcha xizmatlar shaffof narxlarda taqdim etiladi.
          </div>
        </div>
      </div>
    </section>
  );
}
