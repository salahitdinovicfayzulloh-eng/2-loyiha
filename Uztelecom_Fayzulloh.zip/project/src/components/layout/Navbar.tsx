import { useEffect, useState } from 'react';
import { Menu, Moon, Radio, Sun, X } from 'lucide-react';
import { NAV_LINKS } from '@/data/navigation';

const LANGUAGES = ['UZ', 'RU', 'EN'] as const;

interface NavbarProps {
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export default function Navbar({ theme, onToggleTheme }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [language, setLanguage] = useState<(typeof LANGUAGES)[number]>('UZ');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'border-b border-navy-100 bg-white/90 shadow-card backdrop-blur-md dark:border-navy-800 dark:bg-navy-950/90'
          : 'border-b border-transparent bg-white/70 backdrop-blur-sm dark:bg-navy-950/60'
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <a href="#home" onClick={closeMenu} className="group flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500 text-white shadow-sm transition duration-300 group-hover:rotate-6 group-hover:bg-brand-600">
            <Radio className="h-5 w-5" />
          </span>
          <span className="leading-tight">
            <span className="block text-sm font-bold text-navy-900 dark:text-white">Uztelecom Interactive</span>
            <span className="block text-xs text-navy-500 dark:text-navy-300">(Demo Portal)</span>
          </span>
        </a>

        <ul className="hidden items-center gap-1 xl:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.id}>
              <a
                href={`#${link.id}`}
                className="relative rounded-lg px-3 py-2 text-sm font-medium text-navy-700 transition hover:bg-brand-50 hover:text-brand-600 dark:text-navy-200 dark:hover:bg-navy-800 dark:hover:text-brand-300"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <div
            role="group"
            aria-label="Tilni tanlash"
            className="hidden items-center rounded-full border border-navy-200 bg-white p-1 sm:flex dark:border-navy-700 dark:bg-navy-900"
          >
            {LANGUAGES.map((lang) => (
              <button
                key={lang}
                type="button"
                aria-pressed={language === lang}
                onClick={() => setLanguage(lang)}
                className={`rounded-full px-3 py-1 text-xs font-semibold transition ${
                  language === lang
                    ? 'bg-navy-900 text-white dark:bg-brand-500'
                    : 'text-navy-600 hover:text-brand-600 dark:text-navy-200 dark:hover:text-brand-300'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? "Yorug' rejim" : "Qorong'u rejim"}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-navy-200 bg-white text-navy-700 transition duration-300 hover:rotate-12 hover:border-brand-500 hover:text-brand-600 dark:border-navy-700 dark:bg-navy-900 dark:text-navy-100 dark:hover:text-brand-300"
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>

          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label="Menyuni ochish"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-navy-200 bg-white text-navy-700 transition hover:border-brand-500 hover:text-brand-600 xl:hidden dark:border-navy-700 dark:bg-navy-900 dark:text-navy-100"
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      <div
        id="mobile-menu"
        className={`overflow-hidden border-t border-navy-100 bg-white transition-all duration-300 xl:hidden dark:border-navy-800 dark:bg-navy-950 ${
          menuOpen ? 'max-h-[28rem] opacity-100' : 'max-h-0 border-t-0 opacity-0'
        }`}
      >
        <ul className="space-y-1 px-4 py-4">
          {NAV_LINKS.map((link) => (
            <li key={link.id}>
              <a
                href={`#${link.id}`}
                onClick={closeMenu}
                className="block rounded-lg px-3 py-3 text-base font-medium text-navy-800 hover:bg-brand-50 hover:text-brand-600 dark:text-navy-100 dark:hover:bg-navy-800 dark:hover:text-brand-300"
              >
                {link.label}
              </a>
            </li>
          ))}
          <li className="flex items-center gap-2 px-3 pt-3 sm:hidden">
            {LANGUAGES.map((lang) => (
              <button
                key={lang}
                type="button"
                aria-pressed={language === lang}
                onClick={() => setLanguage(lang)}
                className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition ${
                  language === lang
                    ? 'border-brand-500 bg-brand-500 text-white'
                    : 'border-navy-200 text-navy-700 dark:border-navy-700 dark:text-navy-100'
                }`}
              >
                {lang}
              </button>
            ))}
          </li>
        </ul>
      </div>
    </header>
  );
}
