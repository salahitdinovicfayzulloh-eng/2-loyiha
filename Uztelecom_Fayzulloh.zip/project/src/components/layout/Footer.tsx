import { Instagram, Send, Radio } from 'lucide-react';
import { NAV_LINKS } from '@/data/navigation';

const SOCIAL_LINKS = [
  { label: 'Telegram', href: 'https://t.me/Salahitdinov1c', icon: Send },
  { label: 'Instagram', href: 'https://www.instagram.com/g.fayzulloh/', icon: Instagram },
];

export default function Footer() {
  return (
    <footer className="border-t border-navy-100 bg-navy-900 px-4 py-14 text-navy-100 sm:px-6 lg:px-8 dark:border-navy-800 dark:bg-navy-950">
      <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-3">
        <div>
          <a href="#home" className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500 text-white">
              <Radio className="h-5 w-5" />
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-bold text-white">Uztelecom Interactive</span>
              <span className="block text-xs text-navy-300">(Demo Portal)</span>
            </span>
          </a>
          <div className="mt-6 flex gap-3">
            {SOCIAL_LINKS.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={social.label}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-navy-200 transition duration-300 hover:-translate-y-0.5 hover:border-brand-400 hover:bg-brand-500 hover:text-white focus:outline-none focus-visible:ring-4 focus-visible:ring-brand-500/40"
              >
                <social.icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <nav aria-label="Tezkor havolalar">
          <p className="mb-4 text-sm font-semibold uppercase tracking-wider text-white">Tezkor havolalar</p>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
            {NAV_LINKS.map((link) => (
              <li key={link.id}>
                <a href={`#${link.id}`} className="text-navy-200 transition hover:translate-x-1 hover:text-brand-300">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="mb-4 text-sm font-semibold uppercase tracking-wider text-white">Ogohlantirish</p>
          <p className="text-sm leading-relaxed text-navy-300">
            Ushbu sayt rasmiy Uztelecom sayti emas. Barcha narxlar va xizmatlar namoyish uchun ko'rsatilgan.
          </p>
        </div>
      </div>

      <div className="mx-auto mt-12 max-w-7xl border-t border-white/10 pt-6 text-center text-xs text-navy-300">
        © 2026 Developed by Gulomjonov Fayzulloh. Purely educational &amp; portfolio demo project.
      </div>
    </footer>
  );
}
