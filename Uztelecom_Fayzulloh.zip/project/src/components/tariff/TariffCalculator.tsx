import { useMemo, useState, type ReactNode } from 'react';
import { ArrowRight, Gauge, Smartphone } from 'lucide-react';
import {
  INTERNET_TIERS,
  MOBILE_PLANS,
  buildTariffBreakdown,
  type TariffSelection,
} from '@/data/pricing';
import { formatUZS } from '@/lib/format';
import ComparisonTable from '@/components/tariff/ComparisonTable';

const DEFAULT_SELECTION: TariffSelection = {
  internetIndex: 1,
  mobileIndex: 1,
};

interface SliderFieldProps {
  id: string;
  icon: ReactNode;
  label: string;
  valueLabel: string;
  hint: string;
  max: number;
  value: number;
  onChange: (value: number) => void;
}

function SliderField({ id, icon, label, valueLabel, hint, max, value, onChange }: SliderFieldProps) {
  const percent = (value / max) * 100;
  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-4">
        <label htmlFor={id} className="flex items-center gap-2 text-sm font-semibold text-navy-800 dark:text-navy-100">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-50 text-brand-600 dark:bg-navy-800 dark:text-brand-300">
            {icon}
          </span>
          {label}
        </label>
        <span className="rounded-lg bg-navy-900 px-3 py-1 text-sm font-bold text-white dark:bg-brand-500">
          {valueLabel}
        </span>
      </div>
      <input
        id={id}
        type="range"
        min={0}
        max={max}
        step={1}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        style={{
          background: `linear-gradient(to right, #00A3E0 ${percent}%, #D9E4EE ${percent}%)`,
        }}
        className="h-2 w-full cursor-pointer appearance-none rounded-full accent-brand-500 focus:outline-none focus-visible:ring-4 focus-visible:ring-brand-500/30 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:bg-brand-500 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:transition [&::-webkit-slider-thumb]:hover:scale-110"
      />
      <p className="mt-2 text-xs text-navy-500 dark:text-navy-400">{hint}</p>
    </div>
  );
}

export default function TariffCalculator() {
  const [selection, setSelection] = useState<TariffSelection>(DEFAULT_SELECTION);
  const breakdown = useMemo(() => buildTariffBreakdown(selection), [selection]);
  const internet = INTERNET_TIERS[selection.internetIndex];
  const mobile = MOBILE_PLANS[selection.mobileIndex];

  const update = (patch: Partial<TariffSelection>) => setSelection((current) => ({ ...current, ...patch }));

  return (
    <div className="space-y-10">
      <div className="grid gap-6 lg:grid-cols-5">
        <div className="card space-y-8 p-6 sm:p-8 lg:col-span-3">
          <SliderField
            id="internet"
            icon={<Gauge className="h-4 w-4" />}
            label="Internet tezligi"
            valueLabel={`${internet.mbps} Mbit/s`}
            hint="Hammasi birga paketlari bo'yicha rasmiy narx"
            max={INTERNET_TIERS.length - 1}
            value={selection.internetIndex}
            onChange={(internetIndex) => update({ internetIndex })}
          />
          <SliderField
            id="mobile"
            icon={<Smartphone className="h-4 w-4" />}
            label="Mobil tarif"
            valueLabel={mobile.name}
            hint={`${mobile.gb} GB internet, qo'ng'iroq: ${mobile.minutes}`}
            max={MOBILE_PLANS.length - 1}
            value={selection.mobileIndex}
            onChange={(mobileIndex) => update({ mobileIndex })}
          />
        </div>

        <aside className="card relative flex flex-col overflow-hidden p-6 sm:p-8 lg:col-span-2">
          <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-brand-500/10" />
          <p className="text-sm font-semibold uppercase tracking-wider text-navy-500 dark:text-navy-300">
            Oylik narx
          </p>
          <p className="mt-3 text-4xl font-bold tracking-tight text-navy-900 sm:text-5xl dark:text-white">
            {formatUZS(breakdown.comboTotal)}
          </p>
          <p className="mt-2 text-sm text-navy-500 dark:text-navy-300">Uztelecom rasmiy tariflari asosida</p>

          <ul className="mt-8 space-y-3 border-t border-navy-100 pt-6 dark:border-navy-800">
            {breakdown.rows
              .filter((row) => row.combo > 0)
              .map((row) => (
                <li key={row.key} className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-navy-600 dark:text-navy-200">{row.label}</span>
                  <span className="font-semibold text-navy-900 dark:text-white">{formatUZS(row.combo)}</span>
                </li>
              ))}
          </ul>

          <div className="mt-auto pt-8">
            <a href="#b2b" className="btn-secondary w-full">
              Korporativ taklif olish
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </aside>
      </div>

      <ComparisonTable breakdown={breakdown} />
    </div>
  );
}
