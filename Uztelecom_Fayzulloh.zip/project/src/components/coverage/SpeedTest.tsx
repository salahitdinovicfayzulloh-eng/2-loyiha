import { useRef, useState } from 'react';
import { Download, Play, RotateCcw, Upload, Wifi } from 'lucide-react';

type Phase = 'idle' | 'ping' | 'download' | 'upload' | 'done';

interface Metrics {
  ping: number;
  download: number;
  upload: number;
}

const GAUGE_MAX: Record<'ping' | 'download' | 'upload', number> = {
  ping: 100,
  download: 200,
  upload: 100,
};

const GAUGE_RADIUS = 80;
const ARC_LENGTH = (2 * Math.PI * GAUGE_RADIUS * 3) / 4;
const CIRCUMFERENCE = 2 * Math.PI * GAUGE_RADIUS;

const randomBetween = (min: number, max: number) => min + Math.random() * (max - min);
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function SpeedTest() {
  const [phase, setPhase] = useState<Phase>('idle');
  const [gauge, setGauge] = useState(0);
  const [metrics, setMetrics] = useState<Metrics>({ ping: 0, download: 0, upload: 0 });
  const runIdRef = useRef(0);

  const sweep = async (runId: number, target: number, max: number, duration: number) => {
    const steps = Math.round(duration / 40);
    for (let step = 1; step <= steps; step += 1) {
      if (runIdRef.current !== runId) return false;
      const progress = step / steps;
      const eased = 1 - Math.pow(1 - progress, 3);
      const noise = step < steps ? randomBetween(-0.04, 0.04) : 0;
      setGauge(Math.max(0, Math.min(max, target * (eased + noise))));
      await wait(40);
    }
    return true;
  };

  const runTest = async () => {
    const runId = runIdRef.current + 1;
    runIdRef.current = runId;
    setMetrics({ ping: 0, download: 0, upload: 0 });

    const ping = Math.round(randomBetween(6, 28));
    const download = Math.round(randomBetween(85, 180));
    const upload = Math.round(randomBetween(35, 85));

    setPhase('ping');
    if (!(await sweep(runId, ping, GAUGE_MAX.ping, 900))) return;
    setMetrics((current) => ({ ...current, ping }));

    setPhase('download');
    if (!(await sweep(runId, download, GAUGE_MAX.download, 2200))) return;
    setMetrics((current) => ({ ...current, download }));

    setPhase('upload');
    if (!(await sweep(runId, upload, GAUGE_MAX.upload, 1800))) return;
    setMetrics((current) => ({ ...current, upload }));

    setPhase('done');
    setGauge(0);
  };

  const gaugeMax = phase === 'ping' ? GAUGE_MAX.ping : phase === 'upload' ? GAUGE_MAX.upload : GAUGE_MAX.download;
  const fill = Math.min(1, gauge / gaugeMax) * ARC_LENGTH;
  const isRunning = phase !== 'idle' && phase !== 'done';
  const phaseLabel: Record<Phase, string> = {
    idle: 'Tayyor',
    ping: 'Ping o\'lchanmoqda',
    download: 'Yuklab olish tezligi',
    upload: 'Yuklash tezligi',
    done: 'Test yakunlandi',
  };
  const displayValue =
    phase === 'ping' ? gauge.toFixed(0) : phase === 'download' || phase === 'upload' ? gauge.toFixed(1) : '—';
  const unit = phase === 'ping' ? 'ms' : 'Mbps';

  return (
    <div className="card grid gap-8 p-6 sm:p-8 lg:grid-cols-2 lg:items-center">
      <div className="flex flex-col items-center">
        <div className="relative h-64 w-64">
          <svg viewBox="0 0 200 200" className="h-full w-full -rotate-[225deg]" aria-hidden="true">
            <circle
              cx="100"
              cy="100"
              r={GAUGE_RADIUS}
              fill="none"
              strokeWidth="14"
              strokeLinecap="round"
              strokeDasharray={`${ARC_LENGTH} ${CIRCUMFERENCE}`}
              className="stroke-navy-100 dark:stroke-navy-800"
            />
            <circle
              cx="100"
              cy="100"
              r={GAUGE_RADIUS}
              fill="none"
              strokeWidth="14"
              strokeLinecap="round"
              strokeDasharray={`${fill} ${CIRCUMFERENCE}`}
              className="stroke-brand-500 transition-[stroke-dasharray] duration-100"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <Wifi className={`mb-1 h-5 w-5 text-brand-500 ${isRunning ? 'animate-pulse' : ''}`} />
            <span className="text-4xl font-bold tabular-nums text-navy-900 dark:text-white">{displayValue}</span>
            <span className="text-xs font-semibold uppercase tracking-wider text-navy-500 dark:text-navy-300">
              {phase === 'idle' || phase === 'done' ? '\u00a0' : unit}
            </span>
          </div>
        </div>
        <p className="mt-2 text-sm font-medium text-navy-600 dark:text-navy-200">{phaseLabel[phase]}</p>
        <button
          type="button"
          onClick={runTest}
          disabled={isRunning}
          className="btn-primary mt-6 w-full max-w-xs"
        >
          {phase === 'done' ? <RotateCcw className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          {phase === 'idle' ? 'Testni boshlash' : phase === 'done' ? 'Qayta test qilish' : 'Test ketmoqda...'}
        </button>
      </div>

      <div className="grid gap-4">
        {[
          { key: 'ping', label: 'Kechikish (ping)', value: metrics.ping, unit: 'ms', icon: Wifi },
          { key: 'download', label: 'Yuklab olish', value: metrics.download, unit: 'Mbps', icon: Download },
          { key: 'upload', label: 'Yuklash', value: metrics.upload, unit: 'Mbps', icon: Upload },
        ].map((item) => (
          <div
            key={item.key}
            className="flex items-center justify-between rounded-2xl border border-navy-100 bg-navy-50/50 p-5 transition duration-300 hover:-translate-y-0.5 hover:shadow-card dark:border-navy-700 dark:bg-navy-800/60"
          >
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500 text-white">
                <item.icon className="h-5 w-5" />
              </span>
              <span className="font-semibold text-navy-800 dark:text-navy-100">{item.label}</span>
            </div>
            <span className="text-2xl font-bold tabular-nums text-navy-900 dark:text-white">
              {item.value > 0 ? item.value : '—'}
              <span className="ml-1 text-sm font-medium text-navy-500 dark:text-navy-300">{item.unit}</span>
            </span>
          </div>
        ))}
        <p className="text-xs leading-relaxed text-navy-500 dark:text-navy-400">
          Bu demo rejimi: natijalar namoyish uchun tasodifiy generatsiya qilinadi va haqiqiy tarmoq tezligini
          o'lchamaydi.
        </p>
      </div>
    </div>
  );
}
